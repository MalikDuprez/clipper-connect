// app/_layout.tsx
import { Stack } from "expo-router";
import { StatusBar } from "expo-status-bar";
import { SafeAreaProvider } from "react-native-safe-area-context";

export default function RootLayout() {
  return (
    <SafeAreaProvider>
      <StatusBar style="light" />
      <Stack screenOptions={{ headerShown: false }}>
        <Stack.Screen name="(tabs)" />
        <Stack.Screen name="coiffeur/[id]" options={{ presentation: "card" }} />
        <Stack.Screen name="inspiration/[id]" options={{ presentation: "card" }} />
        <Stack.Screen name="booking/service" options={{ presentation: "card" }} />
        <Stack.Screen name="booking/date" options={{ presentation: "card" }} />
        <Stack.Screen name="booking/time" options={{ presentation: "card" }} />
        <Stack.Screen name="booking/confirm" options={{ presentation: "card" }} />
      </Stack>
    </SafeAreaProvider>
  );
}