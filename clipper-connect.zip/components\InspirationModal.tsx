// components/InspirationModal.tsx
import { 
  View, 
  Text, 
  Modal, 
  Pressable, 
  Image, 
  ScrollView, 
  StyleSheet, 
  Dimensions,
  TextInput,
  KeyboardAvoidingView,
  Platform,
  Animated,
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { useState, useRef, useEffect } from "react";
import { useBookingStore } from "../stores/bookingStore";

const { width, height } = Dimensions.get("window");

const theme = {
  background: "#FFFFFF",
  card: "#F8F8F8",
  text: "#000000",
  textSecondary: "#666666",
  textMuted: "#999999",
  border: "#EBEBEB",
  success: "#2E7D32",
  successLight: "#E8F5E9",
  error: "#C62828",
  errorLight: "#FFEBEE",
};

interface InspirationItem {
  id: string;
  title: string;
  category: string;
  duration: string;
  image: string;
  price: number;
  description?: string;
}

interface InspirationModalProps {
  visible: boolean;
  item: InspirationItem | null;
  onClose: () => void;
  onBook: () => void;
}

// Types pour les commentaires avec réponses
interface Reply {
  id: string;
  user: {
    name: string;
    image: string;
  };
  text: string;
  date: string;
  likes: number;
  isOwn: boolean;
  mentionedUser?: string; // @nom de la personne à qui on répond
}

interface Comment {
  id: string;
  user: {
    name: string;
    image: string;
  };
  text: string;
  date: string;
  likes: number;
  isOwn: boolean;
  replies: Reply[];
}

// Mock coiffeur data
const COIFFEUR = {
  id: "1",
  name: "Sophie Martin",
  salon: "Atelier Sophie",
  image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200",
  rating: 4.9,
  reviews: 127,
  distance: "0.8 km",
  isAvailable: true,
};

// Mock stats inspiration
const INSPIRATION_STATS = {
  likes: 234,
  rating: 4.8,
  ratingCount: 47,
  saves: 89,
};

// Mock commentaires avec réponses
const INITIAL_COMMENTS: Comment[] = [
  {
    id: "1",
    user: {
      name: "Marie Dupont",
      image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100",
    },
    text: "Magnifique résultat ! Sophie a fait un travail incroyable sur mes cheveux. Je recommande vivement 💇‍♀️",
    date: "Il y a 2 jours",
    likes: 12,
    isOwn: false,
    replies: [
      {
        id: "1-1",
        user: {
          name: "Sophie Martin",
          image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100",
        },
        text: "Merci beaucoup Marie ! C'était un plaisir de travailler avec toi 🙏",
        date: "Il y a 2 jours",
        likes: 5,
        isOwn: false,
        mentionedUser: "Marie Dupont",
      },
      {
        id: "1-2",
        user: {
          name: "Julie Moreau",
          image: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100",
        },
        text: "Tu as trop de chance ! J'aimerais avoir le même résultat",
        date: "Il y a 1 jour",
        likes: 2,
        isOwn: false,
        mentionedUser: "Marie Dupont",
      },
    ],
  },
  {
    id: "2",
    user: {
      name: "Léa Bernard",
      image: "https://images.unsplash.com/photo-1489424731084-a5d8b219a5bb?w=100",
    },
    text: "J'adore cette coupe ! Est-ce que ça convient aux cheveux fins ?",
    date: "Il y a 5 jours",
    likes: 5,
    isOwn: false,
    replies: [],
  },
  {
    id: "3",
    user: {
      name: "Vous",
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100",
    },
    text: "Super inspiration, j'ai hâte d'essayer !",
    date: "Il y a 1 semaine",
    likes: 3,
    isOwn: true,
    replies: [],
  },
  {
    id: "4",
    user: {
      name: "Claire Martin",
      image: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=100",
    },
    text: "Le balayage est parfait, très naturel. Combien de temps ça prend environ ?",
    date: "Il y a 2 semaines",
    likes: 8,
    isOwn: false,
    replies: [],
  },
];

// Mock disponibilités
const AVAILABLE_DATES = [
  { day: "Aujourd'hui", date: "15 Jan", slots: 3 },
  { day: "Demain", date: "16 Jan", slots: 5 },
  { day: "Jeu", date: "17 Jan", slots: 2 },
  { day: "Ven", date: "18 Jan", slots: 4 },
  { day: "Sam", date: "19 Jan", slots: 1 },
];

const AVAILABLE_TIMES = [
  "09:00", "09:30", "10:00", "10:30", "11:00", 
  "14:00", "14:30", "15:00", "15:30", "16:00", "16:30"
];

type TabType = "reservation" | "commentaires";

// Composant pour afficher une réponse
interface ReplyItemProps {
  reply: Reply;
  onLike: () => void;
  onReply: () => void;
  onDelete: () => void;
  onReport: () => void;
  showMenu: boolean;
  onToggleMenu: () => void;
}

function ReplyItem({ reply, onLike, onReply, onDelete, onReport, showMenu, onToggleMenu }: ReplyItemProps) {
  return (
    <View style={styles.replyCard}>
      <Image source={{ uri: reply.user.image }} style={styles.replyAvatar} />
      <View style={styles.replyContent}>
        <View style={styles.commentHeader}>
          <Text style={styles.replyAuthor}>{reply.user.name}</Text>
          <Text style={styles.commentDate}>{reply.date}</Text>
        </View>
        <Text style={styles.replyText}>
          {reply.mentionedUser && (
            <Text style={styles.mentionText}>@{reply.mentionedUser} </Text>
          )}
          {reply.text}
        </Text>
        <View style={styles.commentActions}>
          <Pressable style={styles.commentAction} onPress={onLike}>
            <Ionicons name="heart-outline" size={13} color={theme.textMuted} />
            <Text style={styles.replyActionText}>{reply.likes}</Text>
          </Pressable>
          <Pressable style={styles.commentAction} onPress={onReply}>
            <Text style={styles.replyActionText}>Répondre</Text>
          </Pressable>
          <Pressable style={styles.commentAction} onPress={onToggleMenu}>
            <Ionicons name="ellipsis-horizontal" size={13} color={theme.textMuted} />
          </Pressable>
        </View>
        
        {/* Menu déroulant */}
        {showMenu && (
          <View style={styles.reportMenu}>
            {reply.isOwn ? (
              <Pressable style={styles.reportMenuItem} onPress={onDelete}>
                <Ionicons name="trash-outline" size={16} color={theme.error} />
                <Text style={[styles.reportMenuText, { color: theme.error }]}>
                  Supprimer
                </Text>
              </Pressable>
            ) : (
              <Pressable style={styles.reportMenuItem} onPress={onReport}>
                <Ionicons name="flag-outline" size={16} color={theme.error} />
                <Text style={[styles.reportMenuText, { color: theme.error }]}>
                  Signaler
                </Text>
              </Pressable>
            )}
          </View>
        )}
      </View>
    </View>
  );
}

export default function InspirationModal({ visible, item, onClose, onBook }: InspirationModalProps) {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { setCurrentBooking } = useBookingStore();
  
  // États
  const [activeTab, setActiveTab] = useState<TabType>("reservation");
  const [selectedDate, setSelectedDate] = useState<number>(0);
  const [selectedTime, setSelectedTime] = useState<string | null>(null);
  const [isLiked, setIsLiked] = useState(false);
  const [isSaved, setIsSaved] = useState(false);
  const [likesCount, setLikesCount] = useState(INSPIRATION_STATS.likes);
  const [newComment, setNewComment] = useState("");
  const [comments, setComments] = useState<Comment[]>(INITIAL_COMMENTS);
  const [showReportMenu, setShowReportMenu] = useState<string | null>(null);
  
  // États pour les réponses style Instagram
  const [replyingTo, setReplyingTo] = useState<{ 
    commentId: string; 
    userName: string;
    isReplyToReply?: boolean;
    replyId?: string;
  } | null>(null);
  const [expandedReplies, setExpandedReplies] = useState<string[]>([]);
  
  // Ref pour l'input
  const inputRef = useRef<TextInput>(null);
  
  // Animation pour le slide
  const slideAnim = useRef(new Animated.Value(height)).current;
  const backdropAnim = useRef(new Animated.Value(0)).current;
  
  // Swipe gesture
  const panY = useRef(new Animated.Value(0)).current;
  const lastGestureY = useRef(0);

  // Ouvrir/Fermer avec animation
  useEffect(() => {
    if (visible) {
      panY.setValue(0);
      Animated.parallel([
        Animated.spring(slideAnim, {
          toValue: 0,
          useNativeDriver: true,
          tension: 65,
          friction: 11,
        }),
        Animated.timing(backdropAnim, {
          toValue: 1,
          duration: 300,
          useNativeDriver: true,
        }),
      ]).start();
    } else {
      Animated.parallel([
        Animated.timing(slideAnim, {
          toValue: height,
          duration: 250,
          useNativeDriver: true,
        }),
        Animated.timing(backdropAnim, {
          toValue: 0,
          duration: 250,
          useNativeDriver: true,
        }),
      ]).start();
    }
  }, [visible]);

  const handleCloseWithAnimation = () => {
    Animated.parallel([
      Animated.timing(slideAnim, {
        toValue: height,
        duration: 250,
        useNativeDriver: true,
      }),
      Animated.timing(backdropAnim, {
        toValue: 0,
        duration: 250,
        useNativeDriver: true,
      }),
    ]).start(() => {
      onClose();
      // Reset states
      setActiveTab("reservation");
      setSelectedDate(0);
      setSelectedTime(null);
      setShowReportMenu(null);
      setReplyingTo(null);
      panY.setValue(0);
    });
  };

  // Gestion du swipe manuel via responders
  const handleTouchStart = (e: any) => {
    lastGestureY.current = e.nativeEvent.pageY;
  };

  const handleTouchMove = (e: any) => {
    const currentY = e.nativeEvent.pageY;
    const diff = currentY - lastGestureY.current;
    
    if (diff > 0) {
      panY.setValue(diff);
    }
  };

  const handleTouchEnd = (e: any) => {
    const currentY = e.nativeEvent.pageY;
    const diff = currentY - lastGestureY.current;
    
    if (diff > 120) {
      handleCloseWithAnimation();
    } else {
      Animated.spring(panY, {
        toValue: 0,
        useNativeDriver: true,
        tension: 65,
        friction: 11,
      }).start();
    }
  };

  if (!item) return null;

  const handleCoiffeurPress = () => {
    handleCloseWithAnimation();
    setTimeout(() => {
      router.push(`/coiffeur/${COIFFEUR.id}`);
    }, 300);
  };

  const handleBook = () => {
    if (selectedTime && item) {
      // Stocker la réservation dans le store
      setCurrentBooking({
        inspiration: {
          id: item.id,
          title: item.title,
          image: item.image,
          category: item.category,
          duration: item.duration,
          price: item.price,
        },
        coiffeur: {
          id: COIFFEUR.id,
          name: COIFFEUR.name,
          salon: COIFFEUR.salon,
          image: COIFFEUR.image,
          rating: COIFFEUR.rating,
        },
        date: AVAILABLE_DATES[selectedDate].day,
        dateFormatted: AVAILABLE_DATES[selectedDate].date,
        time: selectedTime,
      });
      
      handleCloseWithAnimation();
      setTimeout(() => {
        router.push("/booking/checkout");
      }, 300);
    }
  };

  const handleLike = () => {
    setIsLiked(!isLiked);
    setLikesCount(prev => isLiked ? prev - 1 : prev + 1);
  };

  const handleSave = () => {
    setIsSaved(!isSaved);
  };

  // Ajouter un commentaire ou une réponse
  const handleAddComment = () => {
    if (newComment.trim()) {
      if (replyingTo) {
        // Ajouter une réponse
        const newReply: Reply = {
          id: `${replyingTo.commentId}-${Date.now()}`,
          user: {
            name: "Vous",
            image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100",
          },
          text: newComment.trim().replace(`@${replyingTo.userName} `, ""),
          date: "À l'instant",
          likes: 0,
          isOwn: true,
          mentionedUser: replyingTo.userName,
        };
        
        setComments(comments.map(comment => {
          if (comment.id === replyingTo.commentId) {
            return {
              ...comment,
              replies: [...comment.replies, newReply],
            };
          }
          return comment;
        }));
        
        // Déplier automatiquement les réponses de ce commentaire
        if (!expandedReplies.includes(replyingTo.commentId)) {
          setExpandedReplies([...expandedReplies, replyingTo.commentId]);
        }
        
        setReplyingTo(null);
      } else {
        // Ajouter un nouveau commentaire
        const comment: Comment = {
          id: Date.now().toString(),
          user: {
            name: "Vous",
            image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100",
          },
          text: newComment.trim(),
          date: "À l'instant",
          likes: 0,
          isOwn: true,
          replies: [],
        };
        setComments([comment, ...comments]);
      }
      setNewComment("");
    }
  };

  // Répondre à un commentaire
  const handleReplyToComment = (commentId: string, userName: string) => {
    setReplyingTo({ commentId, userName });
    setNewComment(`@${userName} `);
    inputRef.current?.focus();
  };

  // Répondre à une réponse (même commentaire parent)
  const handleReplyToReply = (commentId: string, userName: string) => {
    setReplyingTo({ commentId, userName, isReplyToReply: true });
    setNewComment(`@${userName} `);
    inputRef.current?.focus();
  };

  // Annuler la réponse
  const handleCancelReply = () => {
    setReplyingTo(null);
    setNewComment("");
  };

  // Afficher/masquer les réponses
  const toggleReplies = (commentId: string) => {
    if (expandedReplies.includes(commentId)) {
      setExpandedReplies(expandedReplies.filter(id => id !== commentId));
    } else {
      setExpandedReplies([...expandedReplies, commentId]);
    }
  };

  const handleDeleteComment = (commentId: string) => {
    setComments(comments.filter(c => c.id !== commentId));
    setShowReportMenu(null);
  };

  const handleDeleteReply = (commentId: string, replyId: string) => {
    setComments(comments.map(comment => {
      if (comment.id === commentId) {
        return {
          ...comment,
          replies: comment.replies.filter(r => r.id !== replyId),
        };
      }
      return comment;
    }));
    setShowReportMenu(null);
  };

  const handleReportComment = (commentId: string) => {
    setShowReportMenu(null);
    // En production: envoyer le signalement au backend
  };

  const canBook = selectedTime !== null;

  const translateY = Animated.add(slideAnim, panY);

  // Compter le total des commentaires + réponses
  const totalComments = comments.reduce((acc, c) => acc + 1 + c.replies.length, 0);

  return (
    <Modal visible={visible} transparent statusBarTranslucent animationType="none">
      <View style={styles.container}>
        {/* Backdrop animé */}
        <Animated.View 
          style={[
            styles.backdrop, 
            { opacity: backdropAnim }
          ]}
        >
          <Pressable style={StyleSheet.absoluteFill} onPress={handleCloseWithAnimation} />
        </Animated.View>
        
        {/* Modal Content avec animation */}
        <Animated.View 
          style={[
            styles.modalContent, 
            { 
              transform: [{ translateY }],
            }
          ]}
        >
          <KeyboardAvoidingView 
            behavior={Platform.OS === "ios" ? "padding" : undefined}
            style={{ flex: 1 }}
          >
            <ScrollView 
              showsVerticalScrollIndicator={false}
              bounces={true}
              keyboardShouldPersistTaps="handled"
            >
              {/* Image avec handle intégré */}
              <View style={styles.imageContainer}>
                {/* Zone de swipe avec handle */}
                <View 
                  style={styles.handleZone}
                  onTouchStart={handleTouchStart}
                  onTouchMove={handleTouchMove}
                  onTouchEnd={handleTouchEnd}
                >
                  <View style={styles.handle} />
                </View>
                
                <Image source={{ uri: item.image }} style={styles.image} />
                
                {/* Bouton fermer */}
                <Pressable style={styles.closeButton} onPress={handleCloseWithAnimation}>
                  <Ionicons name="close" size={24} color={theme.text} />
                </Pressable>
                
                {/* Stats en bas à gauche */}
                <View style={styles.statsOverlay}>
                  <View style={styles.statItem}>
                    <Ionicons name="heart" size={14} color="#FFF" />
                    <Text style={styles.statText}>{likesCount}</Text>
                  </View>
                  <View style={styles.statItem}>
                    <Ionicons name="star" size={14} color="#FFB800" />
                    <Text style={styles.statText}>{INSPIRATION_STATS.rating}</Text>
                    <Text style={styles.statSubtext}>({INSPIRATION_STATS.ratingCount})</Text>
                  </View>
                </View>
                
                {/* Actions en bas à droite */}
                <View style={styles.actionsOverlay}>
                  <Pressable style={styles.actionButton} onPress={handleLike}>
                    <Ionicons 
                      name={isLiked ? "heart" : "heart-outline"} 
                      size={24} 
                      color={isLiked ? "#E53935" : "#FFF"} 
                    />
                  </Pressable>
                  <Pressable style={styles.actionButton} onPress={handleSave}>
                    <Ionicons 
                      name={isSaved ? "bookmark" : "bookmark-outline"} 
                      size={24} 
                      color={isSaved ? "#FFB800" : "#FFF"} 
                    />
                  </Pressable>
                </View>
              </View>

              {/* Titre et prix */}
              <View style={styles.titleSection}>
                <View style={styles.titleContainer}>
                  <Text style={styles.title}>{item.title}</Text>
                  <View style={styles.durationRow}>
                    <Ionicons name="time-outline" size={14} color={theme.textMuted} />
                    <Text style={styles.duration}>{item.duration}</Text>
                  </View>
                </View>
                <View style={styles.priceContainer}>
                  <Text style={styles.price}>{item.price}€</Text>
                </View>
              </View>

              {/* Tags descriptifs */}
              <View style={styles.tagsContainer}>
                <View style={styles.tag}>
                  <Text style={styles.tagText}>{item.category}</Text>
                </View>
                {item.category !== "Balayage" && (
                  <View style={styles.tag}>
                    <Text style={styles.tagText}>Balayage</Text>
                  </View>
                )}
                <View style={styles.tag}>
                  <Text style={styles.tagText}>Naturel</Text>
                </View>
                <View style={styles.tag}>
                  <Text style={styles.tagText}>Tendance 2025</Text>
                </View>
              </View>

              {/* Onglets Réservation / Commentaires */}
              <View style={styles.tabsContainer}>
                <Pressable 
                  style={[styles.tab, activeTab === "reservation" && styles.tabActive]}
                  onPress={() => setActiveTab("reservation")}
                >
                  <Ionicons 
                    name="calendar-outline" 
                    size={18} 
                    color={activeTab === "reservation" ? "#FFF" : theme.textMuted} 
                  />
                  <Text style={[styles.tabText, activeTab === "reservation" && styles.tabTextActive]}>
                    Réservation
                  </Text>
                </Pressable>
                <Pressable 
                  style={[styles.tab, activeTab === "commentaires" && styles.tabActive]}
                  onPress={() => setActiveTab("commentaires")}
                >
                  <Ionicons 
                    name="chatbubble-outline" 
                    size={18} 
                    color={activeTab === "commentaires" ? "#FFF" : theme.textMuted} 
                  />
                  <Text style={[styles.tabText, activeTab === "commentaires" && styles.tabTextActive]}>
                    Commentaires ({totalComments})
                  </Text>
                </Pressable>
              </View>

              {/* TAB RÉSERVATION */}
              {activeTab === "reservation" && (
                <View style={styles.content}>
                  {/* Coiffeur Card - Cliquable */}
                  <Pressable style={styles.coiffeurCard} onPress={handleCoiffeurPress}>
                    <Image source={{ uri: COIFFEUR.image }} style={styles.coiffeurImage} />
                    <View style={styles.coiffeurInfo}>
                      <View style={styles.coiffeurNameRow}>
                        <Text style={styles.coiffeurName}>{COIFFEUR.name}</Text>
                        {COIFFEUR.isAvailable && (
                          <View style={styles.availableBadge}>
                            <View style={styles.availableDot} />
                            <Text style={styles.availableText}>Disponible</Text>
                          </View>
                        )}
                      </View>
                      <Text style={styles.coiffeurSalon}>{COIFFEUR.salon}</Text>
                      <View style={styles.coiffeurMeta}>
                        <View style={styles.ratingContainer}>
                          <Ionicons name="star" size={12} color="#FFB800" />
                          <Text style={styles.ratingText}>{COIFFEUR.rating}</Text>
                          <Text style={styles.reviewsText}>({COIFFEUR.reviews})</Text>
                        </View>
                        <View style={styles.distanceContainer}>
                          <Ionicons name="location" size={12} color={theme.textMuted} />
                          <Text style={styles.distanceText}>{COIFFEUR.distance}</Text>
                        </View>
                      </View>
                    </View>
                    <Ionicons name="chevron-forward" size={20} color={theme.textMuted} />
                  </Pressable>

                  {/* Sélection de date */}
                  <View style={styles.section}>
                    <Text style={styles.sectionTitle}>Choisir une date</Text>
                    <ScrollView 
                      horizontal 
                      showsHorizontalScrollIndicator={false}
                      contentContainerStyle={styles.datesContainer}
                    >
                      {AVAILABLE_DATES.map((date, index) => (
                        <Pressable
                          key={index}
                          style={[
                            styles.dateCard,
                            selectedDate === index && styles.dateCardSelected,
                          ]}
                          onPress={() => {
                            setSelectedDate(index);
                            setSelectedTime(null);
                          }}
                        >
                          <Text style={[
                            styles.dateDay,
                            selectedDate === index && styles.dateDaySelected,
                          ]}>
                            {date.day}
                          </Text>
                          <Text style={[
                            styles.dateNumber,
                            selectedDate === index && styles.dateNumberSelected,
                          ]}>
                            {date.date}
                          </Text>
                          <Text style={[
                            styles.dateSlots,
                            selectedDate === index && styles.dateSlotsSelected,
                          ]}>
                            {date.slots} dispo
                          </Text>
                        </Pressable>
                      ))}
                    </ScrollView>
                  </View>

                  {/* Sélection d'heure */}
                  <View style={styles.section}>
                    <Text style={styles.sectionTitle}>Choisir une heure</Text>
                    <View style={styles.timesGrid}>
                      {AVAILABLE_TIMES.map((time) => (
                        <Pressable
                          key={time}
                          style={[
                            styles.timeSlot,
                            selectedTime === time && styles.timeSlotSelected,
                          ]}
                          onPress={() => setSelectedTime(time)}
                        >
                          <Text style={[
                            styles.timeText,
                            selectedTime === time && styles.timeTextSelected,
                          ]}>
                            {time}
                          </Text>
                        </Pressable>
                      ))}
                    </View>
                  </View>

                  {/* Récapitulatif */}
                  {selectedTime && (
                    <View style={styles.summaryCard}>
                      <View style={styles.summaryRow}>
                        <Text style={styles.summaryLabel}>Date</Text>
                        <Text style={styles.summaryValue}>
                          {AVAILABLE_DATES[selectedDate].day}, {AVAILABLE_DATES[selectedDate].date}
                        </Text>
                      </View>
                      <View style={styles.summaryRow}>
                        <Text style={styles.summaryLabel}>Heure</Text>
                        <Text style={styles.summaryValue}>{selectedTime}</Text>
                      </View>
                      <View style={styles.summaryRow}>
                        <Text style={styles.summaryLabel}>Durée</Text>
                        <Text style={styles.summaryValue}>{item.duration}</Text>
                      </View>
                      <View style={[styles.summaryRow, styles.summaryRowTotal]}>
                        <Text style={styles.summaryLabelTotal}>Total</Text>
                        <Text style={styles.summaryValueTotal}>{item.price}€</Text>
                      </View>
                    </View>
                  )}

                  {/* CTA Réservation */}
                  <Pressable 
                    style={[styles.ctaButton, !canBook && styles.ctaButtonDisabled]}
                    onPress={handleBook}
                    disabled={!canBook}
                  >
                    <Text style={styles.ctaText}>
                      {canBook ? "Confirmer la réservation" : "Sélectionnez une heure"}
                    </Text>
                    {canBook && (
                      <View style={styles.ctaPrice}>
                        <Text style={styles.ctaPriceText}>{item.price}€</Text>
                      </View>
                    )}
                  </Pressable>
                </View>
              )}

              {/* TAB COMMENTAIRES */}
              {activeTab === "commentaires" && (
                <View style={styles.content}>
                  {/* Note moyenne */}
                  <View style={styles.ratingOverview}>
                    <View style={styles.ratingBig}>
                      <Ionicons name="star" size={28} color="#FFB800" />
                      <Text style={styles.ratingBigText}>{INSPIRATION_STATS.rating}</Text>
                    </View>
                    <Text style={styles.ratingSubtext}>
                      Basé sur {INSPIRATION_STATS.ratingCount} avis de clients ayant réalisé cette coupe
                    </Text>
                  </View>

                  {/* Input nouveau commentaire / réponse */}
                  <View style={styles.newCommentContainer}>
                    {/* Indicateur de réponse style Instagram */}
                    {replyingTo && (
                      <View style={styles.replyingToContainer}>
                        <Text style={styles.replyingToText}>
                          Réponse à <Text style={styles.replyingToName}>@{replyingTo.userName}</Text>
                        </Text>
                        <Pressable onPress={handleCancelReply} hitSlop={8}>
                          <Ionicons name="close" size={18} color={theme.textMuted} />
                        </Pressable>
                      </View>
                    )}
                    
                    <View style={styles.inputRow}>
                      <Image 
                        source={{ uri: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100" }} 
                        style={styles.newCommentAvatar} 
                      />
                      <View style={styles.newCommentInputWrapper}>
                        <TextInput
                          ref={inputRef}
                          value={newComment}
                          onChangeText={setNewComment}
                          placeholder={replyingTo ? "Écrire une réponse..." : "Ajouter un commentaire..."}
                          placeholderTextColor={theme.textMuted}
                          style={styles.commentTextInput}
                          multiline
                        />
                        {newComment.trim().length > 0 && (
                          <Pressable style={styles.sendButton} onPress={handleAddComment}>
                            <Ionicons name="send" size={18} color="#FFF" />
                          </Pressable>
                        )}
                      </View>
                    </View>
                  </View>

                  {/* Liste des commentaires */}
                  <View style={styles.commentsList}>
                    {comments.map((comment) => (
                      <View key={comment.id}>
                        {/* Commentaire principal */}
                        <View style={styles.commentCard}>
                          <Image source={{ uri: comment.user.image }} style={styles.commentAvatar} />
                          <View style={styles.commentContent}>
                            <View style={styles.commentHeader}>
                              <Text style={styles.commentAuthor}>{comment.user.name}</Text>
                              <Text style={styles.commentDate}>{comment.date}</Text>
                            </View>
                            <Text style={styles.commentText}>{comment.text}</Text>
                            <View style={styles.commentActions}>
                              <Pressable style={styles.commentAction}>
                                <Ionicons name="heart-outline" size={14} color={theme.textMuted} />
                                <Text style={styles.commentActionText}>{comment.likes}</Text>
                              </Pressable>
                              
                              {/* Bouton Répondre */}
                              <Pressable 
                                style={styles.commentAction}
                                onPress={() => handleReplyToComment(comment.id, comment.user.name)}
                              >
                                <Text style={styles.commentActionText}>Répondre</Text>
                              </Pressable>
                              
                              {/* Menu actions (supprimer/signaler) */}
                              <Pressable 
                                style={styles.commentAction}
                                onPress={() => setShowReportMenu(
                                  showReportMenu === comment.id ? null : comment.id
                                )}
                              >
                                <Ionicons name="ellipsis-horizontal" size={14} color={theme.textMuted} />
                              </Pressable>
                            </View>
                            
                            {/* Menu déroulant */}
                            {showReportMenu === comment.id && (
                              <View style={styles.reportMenu}>
                                {comment.isOwn ? (
                                  <Pressable 
                                    style={styles.reportMenuItem}
                                    onPress={() => handleDeleteComment(comment.id)}
                                  >
                                    <Ionicons name="trash-outline" size={16} color={theme.error} />
                                    <Text style={[styles.reportMenuText, { color: theme.error }]}>
                                      Supprimer
                                    </Text>
                                  </Pressable>
                                ) : (
                                  <Pressable 
                                    style={styles.reportMenuItem}
                                    onPress={() => handleReportComment(comment.id)}
                                  >
                                    <Ionicons name="flag-outline" size={16} color={theme.error} />
                                    <Text style={[styles.reportMenuText, { color: theme.error }]}>
                                      Signaler
                                    </Text>
                                  </Pressable>
                                )}
                              </View>
                            )}
                          </View>
                        </View>

                        {/* Bouton voir les réponses */}
                        {comment.replies.length > 0 && !expandedReplies.includes(comment.id) && (
                          <Pressable 
                            style={styles.viewRepliesButton}
                            onPress={() => toggleReplies(comment.id)}
                          >
                            <View style={styles.viewRepliesLine} />
                            <Text style={styles.viewRepliesText}>
                              Voir les {comment.replies.length} réponse{comment.replies.length > 1 ? "s" : ""}
                            </Text>
                          </Pressable>
                        )}

                        {/* Liste des réponses (si déplié) */}
                        {expandedReplies.includes(comment.id) && comment.replies.length > 0 && (
                          <View style={styles.repliesContainer}>
                            {comment.replies.map((reply) => (
                              <ReplyItem
                                key={reply.id}
                                reply={reply}
                                onLike={() => {}}
                                onReply={() => handleReplyToReply(comment.id, reply.user.name)}
                                onDelete={() => handleDeleteReply(comment.id, reply.id)}
                                onReport={() => handleReportComment(reply.id)}
                                showMenu={showReportMenu === reply.id}
                                onToggleMenu={() => setShowReportMenu(
                                  showReportMenu === reply.id ? null : reply.id
                                )}
                              />
                            ))}
                            
                            {/* Bouton masquer les réponses */}
                            <Pressable 
                              style={styles.hideRepliesButton}
                              onPress={() => toggleReplies(comment.id)}
                            >
                              <Text style={styles.hideRepliesText}>Masquer les réponses</Text>
                            </Pressable>
                          </View>
                        )}
                      </View>
                    ))}
                  </View>
                </View>
              )}

              <View style={{ height: insets.bottom + 20 }} />
            </ScrollView>
          </KeyboardAvoidingView>
        </Animated.View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "flex-end",
  },
  backdrop: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: "rgba(0,0,0,0.5)",
  },
  modalContent: {
    backgroundColor: theme.background,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    maxHeight: height * 0.92,
    minHeight: height * 0.7,
    overflow: "hidden",
  },
  
  // Image
  imageContainer: {
    position: "relative",
    marginHorizontal: 16,
    marginTop: 16,
    marginBottom: 16,
  },
  handleZone: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    zIndex: 10,
    alignItems: "center",
    paddingVertical: 12,
  },
  handle: {
    width: 36,
    height: 4,
    backgroundColor: "rgba(255,255,255,0.8)",
    borderRadius: 2,
  },
  image: {
    width: "100%",
    height: 240,
    borderRadius: 20,
  },
  closeButton: {
    position: "absolute",
    top: 36,
    right: 12,
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: "rgba(255,255,255,0.95)",
    alignItems: "center",
    justifyContent: "center",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  statsOverlay: {
    position: "absolute",
    bottom: 12,
    left: 12,
    flexDirection: "row",
    gap: 12,
  },
  statItem: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    backgroundColor: "rgba(0,0,0,0.5)",
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 14,
  },
  statText: {
    fontSize: 12,
    fontWeight: "600",
    color: "#FFF",
  },
  statSubtext: {
    fontSize: 11,
    color: "rgba(255,255,255,0.7)",
  },
  actionsOverlay: {
    position: "absolute",
    bottom: 12,
    right: 12,
    flexDirection: "row",
    gap: 8,
  },
  actionButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: "rgba(0,0,0,0.5)",
    alignItems: "center",
    justifyContent: "center",
  },
  
  // Title Section
  titleSection: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-start",
    paddingHorizontal: 16,
    marginBottom: 20,
  },
  titleContainer: {
    flex: 1,
  },
  title: {
    fontSize: 22,
    fontWeight: "bold",
    color: theme.text,
    marginBottom: 6,
  },
  durationRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
  },
  duration: {
    fontSize: 14,
    color: theme.textMuted,
  },
  priceContainer: {
    backgroundColor: theme.card,
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 12,
  },
  price: {
    fontSize: 20,
    fontWeight: "bold",
    color: theme.text,
  },
  
  // Tags
  tagsContainer: {
    flexDirection: "row",
    flexWrap: "wrap",
    paddingHorizontal: 16,
    marginBottom: 16,
    gap: 8,
  },
  tag: {
    backgroundColor: theme.card,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
  },
  tagText: {
    fontSize: 13,
    color: theme.textSecondary,
    fontWeight: "500",
  },
  
  // Tabs
  tabsContainer: {
    flexDirection: "row",
    paddingHorizontal: 16,
    marginBottom: 20,
    gap: 10,
  },
  tab: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    backgroundColor: theme.card,
    paddingVertical: 12,
    borderRadius: 14,
  },
  tabActive: {
    backgroundColor: theme.text,
  },
  tabText: {
    fontSize: 14,
    fontWeight: "500",
    color: theme.textMuted,
  },
  tabTextActive: {
    color: "#FFF",
  },
  
  // Content
  content: {
    paddingHorizontal: 16,
  },
  
  // Coiffeur Card
  coiffeurCard: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: theme.card,
    borderRadius: 16,
    padding: 14,
    marginBottom: 24,
  },
  coiffeurImage: {
    width: 56,
    height: 56,
    borderRadius: 28,
    marginRight: 12,
  },
  coiffeurInfo: {
    flex: 1,
  },
  coiffeurNameRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    marginBottom: 2,
  },
  coiffeurName: {
    fontSize: 16,
    fontWeight: "600",
    color: theme.text,
  },
  availableBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    backgroundColor: theme.successLight,
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 10,
  },
  availableDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: theme.success,
  },
  availableText: {
    fontSize: 10,
    fontWeight: "600",
    color: theme.success,
  },
  coiffeurSalon: {
    fontSize: 13,
    color: theme.textSecondary,
    marginBottom: 6,
  },
  coiffeurMeta: {
    flexDirection: "row",
    alignItems: "center",
    gap: 16,
  },
  ratingContainer: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
  },
  ratingText: {
    fontSize: 13,
    fontWeight: "600",
    color: theme.text,
  },
  reviewsText: {
    fontSize: 12,
    color: theme.textMuted,
  },
  distanceContainer: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
  },
  distanceText: {
    fontSize: 13,
    color: theme.textMuted,
  },
  
  // Section
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: "600",
    color: theme.text,
    marginBottom: 12,
  },
  
  // Dates
  datesContainer: {
    gap: 10,
    paddingRight: 16,
  },
  dateCard: {
    backgroundColor: theme.card,
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 14,
    alignItems: "center",
    minWidth: 85,
  },
  dateCardSelected: {
    backgroundColor: theme.text,
  },
  dateDay: {
    fontSize: 12,
    color: theme.textMuted,
    marginBottom: 4,
  },
  dateDaySelected: {
    color: "rgba(255,255,255,0.7)",
  },
  dateNumber: {
    fontSize: 15,
    fontWeight: "600",
    color: theme.text,
    marginBottom: 4,
  },
  dateNumberSelected: {
    color: "#FFF",
  },
  dateSlots: {
    fontSize: 11,
    color: theme.success,
    fontWeight: "500",
  },
  dateSlotsSelected: {
    color: "rgba(255,255,255,0.8)",
  },
  
  // Times
  timesGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 10,
  },
  timeSlot: {
    backgroundColor: theme.card,
    paddingVertical: 12,
    paddingHorizontal: 18,
    borderRadius: 12,
  },
  timeSlotSelected: {
    backgroundColor: theme.text,
  },
  timeText: {
    fontSize: 14,
    fontWeight: "500",
    color: theme.text,
  },
  timeTextSelected: {
    color: "#FFF",
  },
  
  // Summary
  summaryCard: {
    backgroundColor: theme.card,
    borderRadius: 16,
    padding: 16,
    marginBottom: 20,
  },
  summaryRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 10,
  },
  summaryRowTotal: {
    marginBottom: 0,
    marginTop: 6,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: theme.border,
  },
  summaryLabel: {
    fontSize: 14,
    color: theme.textMuted,
  },
  summaryValue: {
    fontSize: 14,
    fontWeight: "500",
    color: theme.text,
  },
  summaryLabelTotal: {
    fontSize: 16,
    fontWeight: "600",
    color: theme.text,
  },
  summaryValueTotal: {
    fontSize: 20,
    fontWeight: "bold",
    color: theme.text,
  },
  
  // CTA
  ctaButton: {
    backgroundColor: theme.text,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 16,
    borderRadius: 14,
    gap: 12,
  },
  ctaButtonDisabled: {
    backgroundColor: "#CCC",
  },
  ctaText: {
    fontSize: 16,
    fontWeight: "600",
    color: "#FFF",
  },
  ctaPrice: {
    backgroundColor: "rgba(255,255,255,0.2)",
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 8,
  },
  ctaPriceText: {
    fontSize: 14,
    fontWeight: "bold",
    color: "#FFF",
  },
  
  // Rating Overview (Commentaires tab)
  ratingOverview: {
    alignItems: "center",
    backgroundColor: theme.card,
    borderRadius: 16,
    padding: 20,
    marginBottom: 24,
  },
  ratingBig: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    marginBottom: 8,
  },
  ratingBigText: {
    fontSize: 36,
    fontWeight: "bold",
    color: theme.text,
  },
  ratingSubtext: {
    fontSize: 13,
    color: theme.textMuted,
    textAlign: "center",
    lineHeight: 18,
  },
  
  // New Comment
  newCommentContainer: {
    marginBottom: 24,
  },
  replyingToContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    backgroundColor: theme.card,
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 12,
    marginBottom: 10,
  },
  replyingToText: {
    fontSize: 13,
    color: theme.textMuted,
  },
  replyingToName: {
    color: theme.text,
    fontWeight: "600",
  },
  inputRow: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 12,
  },
  newCommentAvatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
  },
  newCommentInputWrapper: {
    flex: 1,
    flexDirection: "row",
    alignItems: "flex-end",
    backgroundColor: theme.card,
    borderRadius: 16,
    paddingHorizontal: 14,
    paddingVertical: 10,
    gap: 10,
  },
  commentTextInput: {
    flex: 1,
    fontSize: 15,
    color: theme.text,
    maxHeight: 100,
    paddingVertical: 4,
  },
  sendButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: theme.text,
    alignItems: "center",
    justifyContent: "center",
  },
  
  // Comments List
  commentsList: {
    gap: 20,
  },
  commentCard: {
    flexDirection: "row",
    gap: 12,
  },
  commentAvatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
  },
  commentContent: {
    flex: 1,
    backgroundColor: theme.card,
    borderRadius: 16,
    padding: 14,
  },
  commentHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 6,
  },
  commentAuthor: {
    fontSize: 14,
    fontWeight: "600",
    color: theme.text,
  },
  commentDate: {
    fontSize: 12,
    color: theme.textMuted,
  },
  commentText: {
    fontSize: 14,
    color: theme.textSecondary,
    lineHeight: 20,
    marginBottom: 10,
  },
  commentActions: {
    flexDirection: "row",
    alignItems: "center",
    gap: 20,
  },
  commentAction: {
    flexDirection: "row",
    alignItems: "center",
    gap: 5,
  },
  commentActionText: {
    fontSize: 13,
    color: theme.textMuted,
    fontWeight: "500",
  },
  
  // View Replies Button (style Instagram)
  viewRepliesButton: {
    flexDirection: "row",
    alignItems: "center",
    marginLeft: 52,
    marginTop: 12,
    gap: 12,
  },
  viewRepliesLine: {
    width: 24,
    height: 1,
    backgroundColor: theme.textMuted,
  },
  viewRepliesText: {
    fontSize: 13,
    fontWeight: "600",
    color: theme.textMuted,
  },
  
  // Replies Container
  repliesContainer: {
    marginLeft: 52,
    marginTop: 12,
    gap: 12,
  },
  
  // Reply Card (plus petit que commentaire)
  replyCard: {
    flexDirection: "row",
    gap: 10,
  },
  replyAvatar: {
    width: 32,
    height: 32,
    borderRadius: 16,
  },
  replyContent: {
    flex: 1,
    backgroundColor: theme.card,
    borderRadius: 14,
    padding: 12,
  },
  replyAuthor: {
    fontSize: 13,
    fontWeight: "600",
    color: theme.text,
  },
  replyText: {
    fontSize: 13,
    color: theme.textSecondary,
    lineHeight: 18,
    marginBottom: 8,
  },
  replyActionText: {
    fontSize: 12,
    color: theme.textMuted,
    fontWeight: "500",
  },
  mentionText: {
    color: "#3B82F6",
    fontWeight: "600",
  },
  
  // Hide Replies Button
  hideRepliesButton: {
    paddingVertical: 8,
  },
  hideRepliesText: {
    fontSize: 13,
    fontWeight: "600",
    color: theme.textMuted,
  },
  
  // Report Menu
  reportMenu: {
    marginTop: 10,
    backgroundColor: "#FFF",
    borderRadius: 12,
    borderWidth: 1,
    borderColor: theme.border,
    overflow: "hidden",
  },
  reportMenuItem: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    paddingVertical: 12,
    paddingHorizontal: 16,
  },
  reportMenuText: {
    fontSize: 14,
    fontWeight: "500",
  },
});